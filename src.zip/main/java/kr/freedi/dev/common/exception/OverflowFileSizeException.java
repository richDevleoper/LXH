package kr.freedi.dev.common.exception;

@SuppressWarnings("serial")
public class OverflowFileSizeException extends RuntimeException {

}
